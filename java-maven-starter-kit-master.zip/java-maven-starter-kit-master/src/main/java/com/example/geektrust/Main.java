package com.example.geektrust;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import com.example.geektrust.model.Ledger;
import com.example.geektrust.model.LedgerImpl;

public class Main {
    public static void main(String[] args) throws FileNotFoundException  {
    	String filePath = args[0]; //"/Users/B0216779/Documents/Learning/Git/test.txt";
    	Scanner sc = new Scanner(new File(filePath));
    	Ledger ledger = new LedgerImpl();
    	
    	while(sc.hasNext()) {
    		try {
    			ledger.processRecord(sc.nextLine());
    		}catch(Exception e) {
    			
    		}
    	}
	}
}
