package com.example.geektrust.model;

import lombok.Data;

@Data
public class LedgerAccount {
	
	private String borrowerName;
	
	private String bankName;
	
	LedgerAccount(String borrowerName, String bankName){
		this.borrowerName = borrowerName;
		this.bankName = bankName;
	}

	@Override
	public boolean equals(Object acc) {
		LedgerAccount ledgerAcc = (LedgerAccount) acc;
        return (this.bankName.equals(ledgerAcc.getBankName()) && this.borrowerName.equals(ledgerAcc.getBorrowerName()));
    }
	
	@Override
	public int hashCode() {
		return this.bankName.chars().sum();
	}
	
}
