package com.example.geektrust.model;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import com.example.geektrust.constants.PaymentType;

import lombok.Data;

@Data
class Loan{
	private String id;
	private Integer loanAmount;
	private Integer loanAmountToBePaid;
	private int tenure;
	private int emiAmount;
	private double roi;
	private List<Payment> payments;
	
	Loan(int loanAmount, int tenure,double roi){
		this.id =UUID.randomUUID().toString();
		this.payments = new ArrayList<Payment>();
		
		this.loanAmount = loanAmount;
		this.tenure = tenure;
		this.roi = roi;
		this.emiAmount = calculateEmi();
		this.loanAmountToBePaid = emiAmount * tenure * 12;
	}
	
	@Data
	class Payment{
		private PaymentType type;
		private int amount;
		private int emiNumber;
		
		Payment(PaymentType type) {
			this.type = type;
		}
	}
	
	private int calculateEmi() {
		double amountToBePaid = loanAmount + ( (loanAmount * roi * tenure )/100.0 );
		int emiAmount = (int) Math.ceil(amountToBePaid/(tenure*12.0));
		return emiAmount;
	}
	
	public boolean addLumpSumPayment(int amount, int emiNumber) {
		Payment pay = new Payment(PaymentType.LUMPSUM);
		pay.setAmount(amount);
		pay.setEmiNumber(emiNumber);
		return payments.add(pay);
	}

	private int getLumpSumAmountAtEmi(int installmentNumber) {
		return 	payments.stream()
						.filter(a -> a.getEmiNumber() <= installmentNumber)
						.map(a -> a.getAmount())
						.reduce(Integer::sum)
						.orElse(0);
	}

	
	public void balance(String bankName, String borrowerName, int emiNumber) {
		int amountPaid = (emiAmount * emiNumber) + getLumpSumAmountAtEmi(emiNumber);
		int balanceEmi = (int)Math.ceil( (loanAmountToBePaid - amountPaid)/(emiAmount * 1.0) );
		System.out.println(bankName 
				+" "+ borrowerName
				+" "+ amountPaid
				+" "+ balanceEmi
//				+" "+ payments
				);
	}
}