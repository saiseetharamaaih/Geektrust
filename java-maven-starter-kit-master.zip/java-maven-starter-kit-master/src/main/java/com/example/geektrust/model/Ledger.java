package com.example.geektrust.model;

public interface Ledger {
	public void processRecord(String cmd) ;
}
