package com.example.geektrust.model;

import java.util.HashMap;

import lombok.Data;

@Data
public class LedgerImpl implements Ledger {
	
	private final String BALANCE = "BALANCE"; 
	private final String LOAN = "LOAN"; 
	private final String PAYMENT = "PAYMENT"; 

	
	private HashMap<LedgerAccount, Loan> ledger;
	
	public LedgerImpl() {
		ledger = new HashMap<LedgerAccount, Loan>();
	}
	
	public void processRecord(String cmd) {
		cmd.startsWith(LOAN);
		String[] in = cmd.split(" ");
		switch(in[0]) {
		case LOAN : 
			createLoan(in[1], in[2], Integer.valueOf(in[3]), Integer.valueOf(in[4]), Double.valueOf(in[5]));
			break;
		case PAYMENT:
			loanPayment(in[1], in[2], Integer.valueOf(in[3]), Integer.valueOf(in[4]));
			break;
		case BALANCE:
			balance(in[1], in[2], Integer.valueOf(in[3]));
			break;
		}
	}
	
	private void createLoan(String bankName , String borrowerName, int loanAmount, int tenure, double roi) {
		LedgerAccount acc = new LedgerAccount(borrowerName,bankName);
		Loan loan = new Loan(loanAmount, tenure, roi);
		ledger.put(acc, loan);
	}
	
	private void loanPayment(String bankName , String borrowerName, int loanAmount, int installmentNumber) {
		LedgerAccount acc = new LedgerAccount(borrowerName,bankName);
		Loan loan = ledger.get(acc);
		loan.addLumpSumPayment(loanAmount, installmentNumber);
	}
	
	private void balance(String bankName, String borrowerName, int emiNumber) {
		LedgerAccount acc = new LedgerAccount(borrowerName,bankName);
		Loan loan = ledger.get(acc);
		loan.balance(bankName, borrowerName, emiNumber);
	}
	
}
